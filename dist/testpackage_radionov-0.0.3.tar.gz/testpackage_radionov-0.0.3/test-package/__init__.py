def test_print(message):
    print(f'Hello from test package with message: {message}')